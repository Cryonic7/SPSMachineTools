SPS User Tools V1.4 includes:
WallpaperChangerV8.4
TaskViewerV1.6
TaskKillerV1.1

The Readme directions for each tool are below.

Wallpaper Changer for SPS systems V8.1:

	This script only changes the current wallpaper for the current user, on this PC only, IF YOU LOG INTO ANOTHER MACHINE, YOU WILL HAVE TO RUN
	THIS SCRIPT AGAIN

	ALL DESIRED WALLPAPER IMAGES MUST BE PLACED IN THE \PICTURESLIBRARY\ FOLDER TO BE ABLE TO SELECT THEM WITH THE SCRIPT,
	OTHERWISE, THE SCRIPT WILL FAIL

	WARNING:
	--------
	PLEASE DO NOT ABUSE THIS SCRIPT, this should be used only to change from the default background to a nicer background of
	your choice, not to change it to something sexually explicit or otherwise.

	DISCLAIMER:
	------------------
	WARNING: BY USING THIS SCRIPT, YOU HEREBY RELEASE THE AUTHOR AND/OR DISTRIBUTOR OR DISTRIBUTORS FROM ANY AND ALL DISCIPLINARY ACTION 
	THAT MAY RESULT FROM THE USE OF A SEXUALLY EXPLICIT, DISTRACTING, OR OTHERWISE INAPPROPRIATE WALLPAPER. IF AT ANY POINT YOU USE THIS
	SCRIPT IN ANY WAY FOR ANY MALICIOUS ACTION, YOU HEREBY TAKE FULL RESPONSIBILITY FOR ALL CONSEQUENCES INCURRED.

	IF YOU DO NOT WANT TO GET CAUGHT, AND DO NOT WANT TO GET IN TROUBLE, DO NOT USE THIS SCRIPT

	Directions:
	-----------
	1. Make sure the desired wallpaper is inside the folder "PicturesLibrary".

	2. Right click "wallpaperchanger.ps1" and click "Run with Powershell".

	3. Select [W] for WallpaperChanger.

	4. Follow the instructions and enter the filename of the wallpaper you'd like and then after that the filetype of the desired file.

	5. Confirm that it's the desired file, and if so, let the script complete.

	6. The script will now run, and change your wallpaper to that of the desired file.

	7. Enjoy your new wallpaper.

	TO SET ANOTHER, DIFFERENT WALLPAPER:
	------------------------------------
	1. Repeat previous directions

	2. ?????

	3. Profit.

End of WallpaperChanger Readme

Realtime Task and Thread Viewer for SPS Systems V1.3
	
	Run from the menu i guess i dont fuckin know
	this is still bleeding edge
	it leaves it unresponsive and still has artifacts
