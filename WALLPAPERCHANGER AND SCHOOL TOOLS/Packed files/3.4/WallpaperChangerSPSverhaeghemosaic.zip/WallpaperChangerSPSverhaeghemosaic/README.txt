Wallpaper Changer for SPS systems V3.6

This script only changes the current wallpaper for the current user, on this PC only, IF YOU LOG INTO ANOTHER MACHINE, YOU WILL HAVE TO RUN
THIS SCRIPT AGAIN

WARNING:
--------
PLEASE DO NOT ABUSE THIS SCRIPT, this should be used only to change from the default background to a nicer background of
your choice, not to change it to something sexually explicit or otherwise.

DISCLAIMER:
------------------
WARNING: BY USING THIS SCRIPT, YOU HEREBY RELEASE THE AUTHOR FROM ANY AND ALL DISCIPLINARY ACTION THAT MAY RESULT
FROM THE USE OF A SEXUALLY EXPLICIT, DISTRACTING, OR OTHERWISE INAPPROPRIATE WALLPAPER. IF AT ANY POINT YOU USE THIS
SCRIPT IN ANY WAY FOR ANY MALICIOUS ACTION, YOU HEREBY TAKE FULL RESPONSIBILITY FOR ALL CONSEQUENCES INCURRED.

IF YOU DO NOT WANT TO GET CAUGHT, AND DO NOT WANT TO GET IN TROUBLE, DO NOT USE THIS SCRIPT

Directions:
-----------
1. Take the provided file "wallpaper.bmp" and place it in your root folder in H:\ drive
--- Note: wallpaper.bmp can be substituted with any other image by saving it into your H:\ drive as wallpaper.bmp

2. Right click "wallpaperchanger.ps1" and click "Run with Powershell"

3. Wait for the script to run and find the wallpaper to change it with

4. (OPTIONAL) Sometimes the script will ask if you'd like to change execution policy, entering Y will give you
an error that means nothing, so enter Y and wait for the script to finish

5. Enjoy your new wallpaper

TO SET ANOTHER, DIFFERENT WALLPAPER:
------------------------------------

1. Replace wallpaper.bmp with another image of your choice

2. Place it in your H:\ drive root folder

3. Repeat steps of original directions 2-5

4. Enjoy