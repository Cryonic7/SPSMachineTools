Wallpaper Changer for SPS systems V4.0

This script only changes the current wallpaper for the current user, on this PC only, IF YOU LOG INTO ANOTHER MACHINE, YOU WILL HAVE TO RUN
THIS SCRIPT AGAIN

WARNING:
--------
PLEASE DO NOT ABUSE THIS SCRIPT, this should be used only to change from the default background to a nicer background of
your choice, not to change it to something sexually explicit or otherwise.

DISCLAIMER:
------------------
WARNING: BY USING THIS SCRIPT, YOU HEREBY RELEASE THE AUTHOR AND/OR DISTRIBUTOR OR DISTRIBUTORS FROM ANY AND ALL DISCIPLINARY ACTION 
THAT MAY RESULT FROM THE USE OF A SEXUALLY EXPLICIT, DISTRACTING, OR OTHERWISE INAPPROPRIATE WALLPAPER. IF AT ANY POINT YOU USE THIS
SCRIPT IN ANY WAY FOR ANY MALICIOUS ACTION, YOU HEREBY TAKE FULL RESPONSIBILITY FOR ALL CONSEQUENCES INCURRED.

IF YOU DO NOT WANT TO GET CAUGHT, AND DO NOT WANT TO GET IN TROUBLE, DO NOT USE THIS SCRIPT

Directions:
-----------

1. Right click "wallpaperchanger.ps1" and click "Run with Powershell"

2. Wait for the script to run and find the wallpaper to change it with
--- Note: The script may return some errors in deleting the wallpaper if it doesn't already exist, this is normal and the script will still
succeed

3. (OPTIONAL) Sometimes the script will ask if you'd like to change execution policy, enter Y so that the script will continue and complete.
Doing this will sometimes give an error because it could not change the policy computer-wide, but this does not matter.

4. Enjoy your new wallpaper

TO SET ANOTHER, DIFFERENT WALLPAPER:
------------------------------------

1. Replace wallpaper.bmp with another image of your choice

2. Place it in the folder along with your script, so that the script can use it to change

3. Repeat steps of original directions 2-5

4. Enjoy